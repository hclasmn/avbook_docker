<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Javbus extends Model
{
    protected $table = 'avbook_javbus_movie';
    public $timestamps = false;
}
