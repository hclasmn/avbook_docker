<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Series extends Model
{
    protected $table = 'avbook_avmoo_series';
    public $timestamps = false;
}
