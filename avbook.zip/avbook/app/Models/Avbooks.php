<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Avbooks extends Model
{
    protected $table = 'avbook_avmoo_movie';
    public $timestamps = false;




}
