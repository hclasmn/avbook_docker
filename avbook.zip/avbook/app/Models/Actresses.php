<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Actresses extends Model
{
    protected $table = 'avbook_avmoo_star';
    public $timestamps = false;
}
